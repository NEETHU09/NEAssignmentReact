var React = require('react');
var Router = require('react-router');
var Route = Router.Route;
var DefaultRoute = Router.DefaultRoute;

var Main = require('./pages/Main');
var Home = require('./pages/Home');
var Weather = require('./pages/Weather');

module.exports = (
    <Route>
        <Route handler={Main}>
            <DefaultRoute handler={Home} name="Home"/>
        </Route>
        <Route handler={Home} name="HomePage" path="/home"/>
        <Route handler={Weather} name="Weather" path="/weather/*"/>
    </Route>
);
